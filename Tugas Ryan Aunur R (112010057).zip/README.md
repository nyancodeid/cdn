# Web Phising [For Education Purpose Only]
Web phising ini hanya sebagai bahan uji coba mempelajari bagaimana cara kerja phising. Tujuan dibuatnya web phising ini untuk mendapatkan credential melalui duplikasi website SSO (Single Sign On) Universitas Indonesia (UI). 

## Cara Menggunakan
Halaman `/index.php` menampilkan halaman utama login SSO UI yang berisi form login dengan inputan berupa username dan password. Ketika pengguna login menggunakan credential yang dimiliki maka web secara diam diam akan menyimpan informasi credential tersebut dan halaman akan di redirect ke halaman SSO UI yang asli.

Web ini juga bisa dibuka dengan mudah melalui PHP Build-in Web Server dengan menjalankan perintah di-terminal. Dan dapat diakses melalui URL `http://localhost:8080/index.php`.

```bash
$ php -s localhost:8080
```

## Alur Kerja
Alur kerja web ini sederhana yaitu men-duplikasi halaman login SSO UI yang memiliki credential username dan password. Ketika button form submit di klik maka halaman akan mengirim data credential tersebut ke `process.php` melalui metode POST. Dan informasi yang dicatat oleh web ini adalah informasi credential, ip, dan user agent pengguna serta kapan waktu login (timestamp). Informasi tersebut akan disimpan dalam file csv bernama `apatuh.csv`. 

Setelah informasi berhasil dicatat maka halaman akan di redirect ke halaman SSO UI yang asli untuk memberikan kesan credential pengguna salah atau terdapat kekeliruan saat memasukan username/password. Halaman hasil juga bisa dilihat melalui `/hasil.php` untuk tampilan yang lebih interaktif.

## Author
Ryan Aunur Rassyid<<ryandevstudio@gmail.com>>  
Education: Universitas Islam Lamongan<112010057>