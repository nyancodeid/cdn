<?php
/**
 * @author Ryan Aunur Rassyid<112010057>
 */
?>
<!DOCTYPE html>
<html>
<head>
    <title>Hasil Memancing</title>
    <link rel="stylesheet" href="assets/bootstrap-5.min.css">
    <link rel="stylesheet" type="text/css" href="assets/dataTables.bootstrap5.min.css">
    <style>
        .gambar {
            position: fixed;
            top: 16px;
            left: 16px;
            width: 84px;
        }
        .flex-container {
            display: flex;
            justify-content: space-between;
            padding: 1.5em 0;
            align-items: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <img class="gambar" src="assets/mania.webp" alt="">
        <div class="flex-container">
            <h1>Hasil Memancing</h1>
            <h1>Menyala Kailku 🔥</h1>
        </div>
        <table id="csvTable" class="table table-striped table-bordered">
            <thead>
                <?php
                $fileName = 'apatuh.csv';
                if (($handle = fopen($fileName, "r")) !== false) {
                    // Membaca baris pertama sebagai nama kolom
                    $columnNames = fgetcsv($handle, 1000, ",");
                    
                    echo "<tr>";
                    foreach ($columnNames as $columnName) {
                        echo "<th>{$columnName}</th>";
                    }
                    echo "</tr>";

                    fclose($handle);
                }
                ?>
            </thead>
            <tbody>
                <?php
                if (($handle = fopen($fileName, "r")) !== false) {
                    // Melewati baris pertama (nama kolom)
                    $columns = fgetcsv($handle, 1000, ",");

                    while (($data = fgetcsv($handle, 1000, ",")) !== false) {
                        echo "<tr>";
                        foreach ($data as $index => $value) {
                            echo "<td class='$columns[$index]'>{$value}</td>";
                        }
                        echo "</tr>";
                    }
                    fclose($handle);
                }
                ?>
            </tbody>
        </table>
    </div>

    <script src="assets/jquery.min.js"></script>
    <script src="assets/jquery.dataTables.min.js"></script>
    <script src="assets/dataTables.bootstrap5.min.js"></script>
    <script src="assets/ua-parser.min.js"></script>
    <script>
        $(document).ready(function() {
            // parse ua
            $('.user_agent').each(function () {
                const ua = $(this).text();
                const parser = new UAParser(ua);
                const { browser, os } = parser.getResult();

                const child = [
                    `<span class="badge bg-primary">Browser ${browser.name} (${browser.version})</span>`,
                    `<span class="badge bg-secondary">OS ${os.name} (${os.version})</span>`
                ].join('');

                $(this).html(`<div class="d-inline-flex gap-1">${child}</div>`);
            });

            $('#csvTable').DataTable();
        });
    </script>
</body>
</html>